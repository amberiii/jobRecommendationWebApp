package com.laioffer.job.entity;

public class ExampleCoordinates {
    public double latitude;
    public double longitude;

    public ExampleCoordinates(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

}
